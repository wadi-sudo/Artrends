from rest_framework import serializers
from .models import POI
from .models import Urgence
from .models import TrackRating
from drf_extra_fields.fields import Base64ImageField


class POISerializer(serializers.ModelSerializer):
	class Meta:
		model = POI
		fields ='__all__'

class TrackRatingSerializer(serializers.ModelSerializer):
	class Meta:
		model = TrackRating
		fields ='__all__'

class UrgenceSerializer(serializers.ModelSerializer):
	problem_photo = Base64ImageField(required=False)
	class Meta:
		model = Urgence
		fields =['id','created_at','user_confirmation','status','provider_phone_number','problem_photo','description','user_photo','maps_link','y_user','x_user','user_phone_number','user_first_name','user_last_name','selected_service']


