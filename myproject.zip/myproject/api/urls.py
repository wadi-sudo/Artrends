from django.urls import path
from . import views

# from django.contrib.auth import views as auth_views


urlpatterns = [

	path('', views.apiOverview, name="api-overview"),
	path('list-poi/', views.POIList, name="list-poi"),
	path('poi-detail/<str:pk>/', views.POIDetail, name="poi-detail"),
    path('poi-update/<str:pk>/', views.POIUpdate, name="poi-update"),

    path('list-urgence/', views.urgentList, name="list-urgence"),
    path('urgent-detail/<str:pk>/', views.UrgentDetail, name="urgent-detail"),
    path('urgent-create/', views.UrgenceCreate, name="urgent-create"),

    path('urgent-update/<str:pk>/', views.UrgenceUpdate, name="urgent-update"),
    path('urgent-delete/<str:pk>/', views.UrgenceDelete, name="urgent-delete"),

    path('track-list/', views.trackList, name="track-list"),
    path('track-detail/<str:pk>/', views.trackDetail, name="track-detail"),
    path('track-create/', views.trackCreate, name="track-create"),

    path('track-update/<str:pk>/', views.trackUpdate, name="track-update"),

]