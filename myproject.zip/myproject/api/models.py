from django.db import models

# Create your models here.

class POI(models.Model):
    rating_status= [
        ('choice1', '1'),
        ('choice2', '2'),
        ('choice3', '3'),
        ('choice4', '4'),
        ('choice5', '5'),
    ]
    types= [
        ('choices1', 'Mecanisien'),
        ('choices2', 'Electrisian'),
        ('choices3', 'kiosque'),
        ('choices4', 'key_reparation'),
        ('choices5', 'paralélisme'),
    ]
    name = models.CharField(max_length=254, blank=True, null=True)
    service = models.CharField(max_length=254, blank=True, null=True)
    Phone_Number = models.CharField(max_length=12,blank=True,null=True)
    service_type = models.CharField(max_length=20, choices=types, default='choices1')
    rating = models.CharField(max_length=10, choices=rating_status, default='choice1')
    x = models.FloatField(blank=True, null=True)
    y = models.FloatField(blank=True, null=True)
    disponible = models.BooleanField(default=True)
    requested = models.BooleanField(default=False)

    def get_service_type_display_from_api(self, api_service_type):
        for choice in self.SERVICE_TYPE_CHOICES:
            if choice[0] == api_service_type:
                return choice[1]
        return "Unknown"

    def __str__(self):
        return self.name


def file_location(instance, filename, **kwargs):
    file_path = f"photos/{instance.id}-{filename}"
    return file_path

class Urgence(models.Model):
    status_demande =[
        ('choice1', 'En_attente'),
        ('choice2', 'Accepted'),
        ('choice3', 'rejected')
    ]
    status_confirmation =[
        ('choicee1', 'En_attente'),
        ('choicee2', 'confirmed'),
        ('choicee3', 'rejected')
    ]
    id = models.BigAutoField(primary_key=True)
    provider_phone_number = models.CharField(max_length=254, blank=True, null=True)
    selected_service = models.CharField(max_length=254, blank=True, null=True)
    user_last_name = models.CharField(max_length=254, blank=True, null=True)
    user_first_name = models.CharField(max_length=254, blank=True, null=True)
    user_phone_number = models.CharField(max_length=254, blank=True, null=True)
    x_user = models.FloatField(blank=True, null=True)
    y_user = models.FloatField(blank=True, null=True)
    maps_link = models.CharField(max_length=254, blank=True, null=True)
    status = models.CharField(max_length=10, choices=status_demande, default='choice1')
    user_confirmation = models.CharField(max_length=10, choices=status_confirmation, default='choicee1')
    user_photo = models.CharField(max_length=254, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    description = models.CharField(max_length=1000, blank=True, null=True)
    problem_photo = models.ImageField(upload_to=file_location, blank=True, null=True)



    def __str__(self):
        return self.user_phone_number




class TrackRating(models.Model):
    id = models.BigAutoField(primary_key=True)
    provider_number = models.CharField(max_length=254, blank=True, null=True)
    provider_service = models.CharField(max_length=254, blank=True, null=True)
    provider_name =models.CharField(max_length=254, blank=True, null=True)
    consumer_number = models.CharField(max_length=254, blank=True, null=True)
    decription = models.CharField(max_length=254, blank=True, null=True)
    price = models.CharField(max_length=254, blank=True, null=True)
    rating = models.CharField(max_length=1,default='0',blank=True, null=True)
    
    def __str__(self):
        return self.provider_name