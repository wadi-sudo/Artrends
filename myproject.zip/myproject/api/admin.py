from django.contrib import admin

# Register your models here.
from .models import POI
from .models import Urgence
from .models import TrackRating
admin.site.register(POI)
admin.site.register(TrackRating)
admin.site.register(Urgence)