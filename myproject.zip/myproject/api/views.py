from django.shortcuts import render, redirect
from django.http import JsonResponse
from .forms import PositionForm
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import POISerializer
from .serializers import UrgenceSerializer
from .serializers import TrackRatingSerializer
from django.contrib.auth.decorators import login_required

from .models import POI
from .models import Urgence
from .models import TrackRating
from django.urls import reverse_lazy
# Create your views here.

from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.list import ListView
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.decorators import api_view, parser_classes

@api_view(['GET'])
def apiOverview(request):
	api_urls = {
		'List pois ':'/list-poi/',
		'List urgent':'/list-urgence/',
		'Detail View for poi':'/poi-detail/<str:pk>/',
        'Detail View for urgent':'/urgent-detail/<str:pk>/',
		'Create urgent':'/urgent-create/',
		'Update urgent':'/urgent-update/<str:pk>/',
        'Update poi':'/poi-update/<str:pk>/',
		'Delete urgent':'/urgent-delete/<str:pk>/',
		'list track rate':'/track-list/'
		}

	return Response(api_urls)
@api_view(['GET'])
def POIList(request):
	
	#search_query = request.GET.get('search', '')
	#pois = POI.objects.filter(name__icontains=search_query).order_by('-id')
	service_types = request.GET.getlist('service_type')

	if service_types:
		pois = POI.objects.filter(service_type__in=service_types).order_by('-id')
	else:
		pois = POI.objects.all().order_by('-id')
	serializer = POISerializer(pois, many=True)
	return Response(serializer.data)



# class POIList(ListView):
#     model = POI
#     context_object_name = 'list-poi'

#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         #context['list-poi'] = context['list-poi'].filter(user=self.request.user)
#         context['list-poi'] = POI.objects.all()

#         search_input = self.request.GET.get('search-area') or ''
#         if search_input:
#             context['list-poi'] = context['list-poi'].filter(
#                 name__contains=search_input)

#         context['search_input'] = search_input

#         return context


@api_view(['GET'])
def POIDetail(request, pk):
	poi = POI.objects.get(id=pk)
	serializer = POISerializer(poi, many=False)
	return Response(serializer.data)

@api_view(['POST'])
def POIUpdate(request, pk):
	poi = POI.objects.get(id=pk)
	serializer = POISerializer(instance=poi, data=request.data)

	if serializer.is_valid():
		serializer.save()

	return Response(serializer.data)
# @method_decorator(staff_member_required, name='dispatch')

@api_view(['GET'])
def urgentList(request):
	urgents = Urgence.objects.all().order_by('-id')

	serializer = UrgenceSerializer(urgents, many=True)
	return Response(serializer.data)

@api_view(['GET'])
def UrgentDetail(request, pk):
	urgents = Urgence.objects.get(id=pk)
	serializer = UrgenceSerializer(urgents, many=False)
	return Response(serializer.data)

@api_view(['POST'])
def UrgenceCreate(request):
    if request.method == "POST":
        data = request.data
        serializer = UrgenceSerializer(data=data)
        if serializer.is_valid():
            article = serializer.save()
            data = serializer.data
            return Response(data=data)
        return Response(serializer.errors, status=400)

@api_view(['GET', 'POST'])
def UrgenceUpdate(request, pk):
	urgent = Urgence.objects.get(id=pk)
	serializer = UrgenceSerializer(instance=urgent, data=request.data)

	if serializer.is_valid():
		serializer.save()

	return Response(serializer.data)


@api_view(['DELETE'])
def UrgenceDelete(request, pk):
	urgent = Urgence.objects.get(id=pk)
	urgent.delete()

	return Response('Item succsesfully delete!')


##############################################################################

@api_view(['GET'])
def trackList(request):
	tracks = TrackRating.objects.all().order_by('-id')

	serializer = TrackRatingSerializer(tracks, many=True)
	return Response(serializer.data)

@api_view(['GET'])
def trackDetail(request, pk):
	track = TrackRating.objects.get(id=pk)
	serializer = TrackRatingSerializer(track, many=False)
	return Response(serializer.data)

@api_view(['POST'])
def trackCreate(request):
    if request.method == "POST":
        data = request.data
        serializer = TrackRatingSerializer(data=data)
        if serializer.is_valid():
            article = serializer.save()
            data = serializer.data
            return Response(data=data)
        return Response(serializer.errors, status=400)

@api_view(['GET', 'POST'])
def trackUpdate(request, pk):
	track = TrackRating.objects.get(id=pk)
	serializer = TrackRatingSerializer(instance=track, data=request.data)

	if serializer.is_valid():
		serializer.save()

	return Response(serializer.data)