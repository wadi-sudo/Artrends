# signals.py
from django.db.models.signals import post_save
from django.dispatch import Signal, receiver
from api.models import Urgence, TrackRating ,POI
from .models import CustomUser
import requests
from math import radians, sin, cos, sqrt, atan2
from django.core.cache import cache
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from .sse_utils import connected_clients
import json
from django.utils import timezone
from threading import Timer
from django.db.models import Avg
from django.db.models.functions import Cast
from django.db.models import FloatField
from django.conf import settings

send_notification_signal = Signal()

@receiver(post_save, sender=Urgence)
def new_element_added(sender, instance, created, **kwargs):
    if created:
        prev_instances=[]
        # print("A new element was added!")
        # print("provider_phone_number:", instance.provider_phone_number)
        # print("selected_service:", instance.selected_service)
        # print("user_last_name:", instance.user_last_name)
        # print("user_first_name:", instance.user_first_name)
        # print("user_phone_number:", instance.user_phone_number)
        # print("x_user:", instance.x_user)
        # print("y_user:", instance.y_user)
        # print("maps_link:", instance.maps_link)
        # print("status:", instance.status)
        # print("user_confirmation:", instance.user_confirmation)
        prev_instance = cache.get(f'urgent_{instance.pk-1}')
        prev_instance2 = cache.get(f'urgent_{instance.pk-2}')
        prev_instance3 = cache.get(f'urgent_{instance.pk-3}')
        if prev_instance:      
            prev_instances.append(prev_instance)
        if prev_instance2:
            prev_instances.append(prev_instance2)
        if prev_instance3:
            prev_instances.append(prev_instance3)
        #print('previous_instances',prev_instances )
        api_url = settings.BASE_ADDRESS + "/api/list-poi/"  
        response = requests.get(api_url)
        # if prev_instances:
        #     print([(prev_instance.provider_phone_number) for prev_instance in prev_instances])
        if response.status_code == 200:

            lat1 = radians(instance.x_user)
            lon1 = radians(instance.y_user)
            
            # Process API data
            api_data = response.json()
            
            # Initialize variables for storing the closest element and its distance
            closest_element = None
            min_distance = float('inf')  # Initialize with infinity
            
            # Loop through API data to find the closest element
            for item in api_data:
                if item['service_type']!="choices3":
                    #print('item: ',get_service_type_display_from_api(item['service_type']), 'instance: ',instance.selected_service)
                    if item['service_type']=="choices1":
                        item['service_type']= 'Mecanisien'
                    elif item['service_type']=="choices2":
                        item['service_type']="Electrisian"
                    elif item['service_type']=="choices4":
                        item['service_type']="Key_reparation"
                    elif item['service_type']=="choices5":
                        item['service_type']="paralélisme"



                    user_dispo= CustomUser.objects.filter(phone_number=item['Phone_Number']).first()
                    if user_dispo.available :
                        if prev_instances:
                            if item['service_type'] == instance.selected_service and all(prev_instance.provider_phone_number != item['Phone_Number'] for prev_instance in prev_instances) :

                                # Get coordinates of the current element
                                lat2 = radians(item['x'])
                                lon2 = radians(item['y'])
                                # Calculate distance using Haversine formula
                                dlat = lat2 - lat1
                                dlon = lon2 - lon1
                                a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
                                c = 2 * atan2(sqrt(a), sqrt(1 - a))
                                distance = 6371 * c  # Radius of the Earth in kilometers
                                if distance < min_distance:
                                    min_distance = distance
                                    closest_element = item
                        else:
                            if item['service_type'] == instance.selected_service :
                                user_dispo= CustomUser.objects.filter(phone_number=item['Phone_Number']).first()

                                # Get coordinates of the current element
                                lat2 = radians(item['x'])
                                lon2 = radians(item['y'])
                                # Calculate distance using Haversine formula
                                dlat = lat2 - lat1
                                dlon = lon2 - lon1
                                a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
                                c = 2 * atan2(sqrt(a), sqrt(1 - a))
                                distance = 6371 * c  # Radius of the Earth in kilometers
                                if distance < min_distance:
                                    min_distance = distance
                                    closest_element = item
            
            # Update a value in the new element with closest element data
            if closest_element:
                instance.provider_phone_number = closest_element['Phone_Number']
                #send_notification_signal.send(sender=Urgence, idd=instance.id, phone_number=instance.provider_phone_number,consumer_last=instance.user_last_name,consumer_first=instance.user_first_name,consumer_number=instance.user_phone_number,consumer_maps_link=instance.maps_link,consumer_photo=instance.user_photo)
            elif prev_instances:
                last_prev_instance = cache.get(f'urgent_{instance.pk-1}')
                instance.provider_phone_number = last_prev_instance.provider_phone_number
                #send_notification_signal.send(sender=Urgence, idd=instance.id, phone_number=instance.provider_phone_number,consumer_last=instance.user_last_name,consumer_first=instance.user_first_name,consumer_number=instance.user_phone_number,consumer_maps_link=instance.maps_link,consumer_photo=instance.user_photo)
            else:
                instance.provider_phone_number= '000000000000'
            
            instance.creation_timestamp = timezone.now()
            instance.save()
                    # Schedule a Timer to check field alteration after 10 seconds
            t = Timer(15, check_field_alteration, args=[instance.id])
            t.start()
            cache_key = f'urgent_{instance.pk}'
            cache.set(cache_key, instance, 60)
            channel_layer = get_channel_layer()

            print(f'sending notification onlyyyyyyyyyyyyyyyyyyy to {instance.provider_phone_number}')
            print((timezone.now() - instance.created_at.astimezone(timezone.utc)).total_seconds() )
            

    if not created :
        old_instance = Urgence.objects.get(pk=instance.pk)
        if instance.status != old_instance.status:
            print('it is working wadiiiiiiiiiiiiiiii')

def send_notification_to_user(user, instance):
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f"user_{user.id}",
        {
            'type': 'notify.user',
            'message': f'A new element with id {instance.id} has been created.',
        }
    )

def check_field_alteration(instance_id):
    instance = Urgence.objects.get(id=instance_id)
    elapsed_time = timezone.now() - instance.created_at.astimezone(timezone.utc)
    print('counter working',instance.user_confirmation)
    if instance.problem_photo:
        photo_value = instance.problem_photo.url
    else:
        photo_value=''
    if instance.user_confirmation == 'choicee2':
        send_notification_signal.send(sender=Urgence, idd=instance.id, phone_number=instance.provider_phone_number,consumer_last=instance.user_last_name,consumer_first=instance.user_first_name,consumer_number=instance.user_phone_number,consumer_maps_link=instance.maps_link,consumer_photo=instance.user_photo,consumer_x=instance.x_user,consumer_y=instance.y_user,desc=instance.description,problem_photo=photo_value)
        # The field has been altered within the specified time frame
        # Perform your desired actions here
        print(f"Field altered within 10 seconds: {instance.user_confirmation}")


@receiver(post_save, sender=TrackRating)
def check_field(sender, instance, created, **kwargs):
    if created:
        # Get all TrackRating instances
        all_track_ratings = TrackRating.objects.all()

        # Group by provider_number and calculate average rating
        provider_ratings = (
            all_track_ratings
            .annotate(rating_as_float=Cast('rating', FloatField()))  # Convert rating to a float
            .values('provider_number')
            .annotate(avg_rating=Avg('rating_as_float'))  # Calculate average rating
        )

        # Print or use the average ratings for each provider
        for provider in provider_ratings:
            provider_number = provider['provider_number']
            average_rating = provider['avg_rating']
            average_rating_int = round(average_rating)
            # Ensure the average rating is within the range of 1 to 5
            average_rating2 = max(1, min(5, average_rating_int))
            print(f"Provider Number: {provider_number}, Average Rating: {average_rating2}")
            
            poi_instance = POI.objects.get(Phone_Number=provider_number)
            if average_rating2==1:
                poi_instance.rating = 'choice1'
            if average_rating2==2:
                poi_instance.rating = 'choice2'
            if average_rating2==3:
                poi_instance.rating = 'choice3'
            if average_rating2==4:
                poi_instance.rating = 'choice4'
            if average_rating2==5:
                poi_instance.rating = 'choice5'
            poi_instance.save()