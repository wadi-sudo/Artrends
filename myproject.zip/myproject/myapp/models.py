from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    USER_TYPE_CHOICES = (
        ('consumer', 'Consumer'),
        ('provider', 'Provider'),
    )

    phone_number = models.CharField(max_length=15, unique=True)
    user_type = models.CharField(max_length=10, choices=USER_TYPE_CHOICES, default='consumer')
    description = models.TextField(blank=True, null=True)
    photo = models.ImageField(upload_to='user_photos/', blank=True, null=True)
    available = models.BooleanField(default=False)

class UserProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    description = models.TextField(blank=True, null=True)  # Only for providers

# You may also add other fields like address, etc.
AUTH_USER_MODEL = 'myapp.CustomUser'
USERNAME_FIELD = 'phone_number'


class TrackLocation(models.Model):
    id = models.BigAutoField(primary_key=True)
    provider_number = models.CharField(max_length=254, blank=True, null=True)
    consumer_number = models.CharField(max_length=254, blank=True, null=True)
    provider_x = models.FloatField(blank=True, null=True)
    provider_y = models.FloatField(blank=True, null=True)
    consumer_x = models.FloatField(blank=True, null=True)
    consumer_y = models.FloatField(blank=True, null=True)



