// add hovered class to selected list item
let list = document.querySelectorAll(".navigation li");

function activeLink() {
  list.forEach((item) => {
    item.classList.remove("hovered");
    
    });
  this.classList.add("hovered");
  hideSidebar()
}

//list.forEach((item) => item.addEventListener("mouseover", activeLink));

// Menu Toggle
let toggle = document.querySelector(".toggle");
let navigation = document.querySelector(".navigation");
let main = document.querySelector(".main");

toggle.onclick = function () {
  navigation.classList.toggle("active");
  main.classList.toggle("active");
};

function hideSidebar() {
  navigation.classList.remove("active");
  main.classList.remove("active");
  //navigation.style.width = "0px";
}
list.forEach((item) => {
  //item.addEventListener("mouseover", activeLink);
  item.addEventListener("click", function () {
    hideSidebar(); // Hide the sidebar when a list item is clicked
  });
});
