from django.urls import path
from . import views
from django.contrib.auth import views as auth_view
#from .views import CustomLoginView
from django.contrib.auth.views import LogoutView
from .views import login_view, register_view, verify_registration_view, sse, update_available_status
from .views import update_provider_location, get_consumer_location

urlpatterns = [
    
	path('', views.index, name='home'),
    #path('login/', CustomLoginView.as_view(), name='login'),
    path('login/', login_view, name='login'),
    path('register/', register_view, name='register'),
    path('verify-registration/', verify_registration_view, name='verify_registration'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    #path("register", views.register, name="register"),
    path('admin/', views.admin, name='admin'),
    #path('update-profile/', update_profile, name='update_profile'),
    path('sse/<str:phone_number>/', sse, name='sse'),
    path('update_available_status/', update_available_status, name='update_available_status'),
    path('update_provider_location/', update_provider_location, name='update_provider_location'),
    # path('trackrating/', trackrating, name='trackrating'),
    path('get_consumer_location/<str:consumer_number>/', get_consumer_location, name='get_consumer_location'),

]



