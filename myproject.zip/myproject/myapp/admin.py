from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser,UserProfile, TrackLocation

class CustomUserAdmin(UserAdmin):
    # Customize the display and ordering of fields in the admin list view if needed
    list_display = ['username', 'email', 'phone_number','user_type','available','is_active', 'is_staff', 'is_superuser']
    list_filter = ['is_active', 'is_staff', 'is_superuser','user_type','available']

    # Customize the form used for creating and updating user instances
    fieldsets = (
        (None, {'fields': ('photo','username', 'email', 'password')}),
        ('Personal Info', {'fields': ('first_name', 'last_name', 'phone_number','description')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser','available')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )

    # Specify the form and fieldsets to use in the add and change views
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('photo','username', 'email', 'phone_number', 'password1', 'password2','description','is_active', 'is_staff', 'is_superuser','user_type'),
        }),
    )

admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(UserProfile)
admin.site.register(TrackLocation)
