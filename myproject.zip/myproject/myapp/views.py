from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
#from .forms import PositionForm, NewUserForm, RegistrationForm
from django.urls import reverse_lazy

from django.contrib.auth.decorators import user_passes_test
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView

from django.contrib.auth.views import LoginView

#from django.contrib.auth import login
from django.http import HttpResponse
from django.http import JsonResponse
from django.http import  Http404, HttpResponseBadRequest
from .models import TrackLocation
import json
# phoneauth/views.py
import string
from django.views.decorators.http import require_POST
import random
from django.contrib.auth import authenticate, login
from .forms import LoginForm,UserProfileForm,UserProfileForm2, ProblemForm
from .forms import ConsumerRegistrationForm, ProviderRegistrationForm
from .models import CustomUser, UserProfile
from twilio.rest import Client
from django.conf import settings

# Set up Twilio client
account_sid = 'ACd3bc88db859b3b6f0a213ca89f475ef8'
auth_token = 'f6b7a22a6f458b6cef66976d79114cbb'
twilio_phone_number = '+16182474517'

client = Client(account_sid, auth_token)
def send_verification_code(phone_number, code):
    message = client.messages.create(
        body=f'Your verification code is: {code}',
        from_=twilio_phone_number,
        to=phone_number
    )

    return message.sid
def generate_verification_code(length=6):
    """Generate a random verification code."""
    characters = string.digits
    verification_code = ''.join(random.choice(characters) for i in range(length))
    return verification_code



def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        
        if form.is_valid():
            
            phone_number = form.cleaned_data['phone_number']
            password = form.cleaned_data['password']
            user = authenticate(request, phone_number=phone_number, password=password)
            print(user)

            if user is not None:
                login(request, user)
                redirect_authenticated_user = True
                return redirect('home')  # Replace 'home' with the actual name of your home URL pattern
            else:
                messages.error(request, 'Invalid phone number or password.')
        else:
            messages.error(request, 'Form validation failed. Please check your input.')

    else:
        form = LoginForm()

    return render(request, 'myapp/login.html', {'form': form})

# def login_view(request):
#     if request.method == 'POST':
#         phone_number = request.POST['phone_number']
#         password = request.POST['password']
#         user = authenticate(request, phone_number=phone_number, password=password)
        
#         if user is not None:
#             login(request, user)
#             return redirect('home')
            
#         else:
#             messages.error(request, 'Invalid phone number or password.')

#    return render(request, 'myapp/login.html')
def register_view(request):
    if request.method == 'POST':
        user_type = request.POST.get('user_type')

        if user_type == 'consumer':
            form = ConsumerRegistrationForm(request.POST)
        elif user_type == 'provider':
            form = ProviderRegistrationForm(request.POST)
        else:
            form = None

        if form and form.is_valid():
            
            user = form.save(commit=False)
            user.is_active = False
            user.save()
            request.session['user_id'] = user.id
            # Generate and store the verification code in the session
            verification_code = generate_verification_code()
            request.session['stored_verification_code'] = verification_code

            # Send verification code to user's phone number
            send_verification_code(user.phone_number, verification_code)
            
            messages.success(request, 'Check your phone for verification code.')
            return redirect('verify_registration')

    else:
        form = ConsumerRegistrationForm()

    return render(request, 'myapp/register.html', {'form': form})
# def register_view(request):
#     if request.method == 'POST':
#         user_type = request.POST.get('user_type')

#         if user_type == 'consumer':
#             form = ConsumerRegistrationForm(request.POST)
#             if form.is_valid():
#                 user = form.save(commit=False)
#                 user.user_type = 'consumer'
#                 user.set_password(form.cleaned_data['password'])
#                 user.save()
#                 verification_code = generate_verification_code()
#                 request.session['stored_verification_code'] = verification_code
#                 send_verification_code(user.phone_number, verification_code)
#                 messages.success(request, 'Registration successful. Check your phone for verification code.')
       
#                 return redirect('verify_registration')
#         elif user_type == 'provider':
#             user_form = ProviderRegistrationForm(request.POST)
#             profile_form = UserProfileForm(request.POST)
#             if user_form.is_valid() and profile_form.is_valid():

#                 user = user_form.save(commit=False)
#                 user.user_type = 'provider'
#                 user.set_password(user_form.cleaned_data['password'])
#                 user.save()

#                 profile = profile_form.save(commit=False)
#                 profile.user = user
#                 profile.save()

#                 verification_code = generate_verification_code()
#                 request.session['stored_verification_code'] = verification_code
#                 send_verification_code(user.phone_number, verification_code)
#                 messages.success(request, 'Registration successful. Check your phone for verification code.')
          
#                 return redirect('verify_registration')
#     else:
#         form = ConsumerRegistrationForm()  # Default to consumer registration

#     return render(request, 'myapp/register.html', {'form': form})


def verify_registration_view(request):
    context = {}
    if request.method == 'POST':
        verification_code_entered = request.POST.get('verification_code')

        # Perform verification here
        # For simplicity, let's assume that we stored the verification code in the session during registration
        stored_verification_code = request.session.get('stored_verification_code')

        if verification_code_entered == stored_verification_code:
            
            request.session.pop('stored_verification_code', None)

            # Retrieve the user object based on the user ID or any other identifier
            user_id = request.session.get('user_id')
            user = CustomUser.objects.get(pk=user_id)

            # Make the user active
            if user.user_type == 'consumer':
                user.is_active = True
                user.save()
            messages.success(request, 'Registration successfully verified. You can now log in.')
            return redirect('login')
        else:
            messages.error(request, 'Invalid verification code. Please try again.')
    context['messages'] = messages.get_messages(request)

    return render(request, 'myapp/verify_registration.html',context)

# def register(request):
#     if request.method == 'POST':
#         form = RegistrationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('index')
#     else:
#         form = RegistrationForm()
#     return render(request, 'myapp/register.html', {'form': form})


# class CustomLoginView(LoginView):
#     template_name = 'myapp/login.html'
#     fields = '__all__'
#     redirect_authenticated_user = True

#     def get_success_url(self):
#         return reverse_lazy('home')

@login_required()
def index(request):
    
    # if request.method == 'POST':
    #     form0 = ProblemForm(request.POST, request.FILES)
    #     if form0.is_valid():
    #         instance = form0.save()
    #         # You can do further processing if needed
    #         #return redirect('success')  # Redirect to a success page
    # else:
    #     form0 = ProblemForm()

    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
    else:
        form = UserProfileForm(instance=request.user)

    if request.method == 'POST':
        form2 = UserProfileForm2(request.POST, request.FILES, instance=request.user)
        if form2.is_valid():
            form2.save()
    else:
        form2 = UserProfileForm2(instance=request.user)

    if request.user.is_active and request.user.user_type=='consumer':
        return render(request, 'myapp/index.html', {'form': form})
    elif request.user.is_active and request.user.user_type=='provider':
        return render(request, 'myapp/indexP.html', {'form': form2})
    else :
        return HttpResponse("We will contact you soon for your account activation.  ")
    # if request.user.groups.filter(name='SimpleUser').exists():
    #     return render(request, 'myapp/index.html')
    # else:
    #     return HttpResponse("the application still under developement ... ")

@login_required()
def admin(request): return render(request, 'myapp/profile.html')

# @login_required
# def update_profile(request):
#     user = request.user

#     if request.is_ajax():
#         try:
#             data = json.loads(request.body.decode('utf-8'))
#             form = UserProfileForm(data,request.FILES, instance=user)

#             if form.is_valid():
#                 form.save()
#                 updated_data = {
#                     'username': user.username,
#                     'phone_number': user.phone_number,
#                     'last_name': user.last_name,
#                     'first_name': user.first_name,
#                     'photo': str(user.photo.url) if user.photo else None,
#                     # Add other fields as needed
#                 }
#                 return JsonResponse(updated_data)
#             else:
#                 errors = form.errors.as_json()
#                 return JsonResponse({'error': errors}, status=400)

#         except json.JSONDecodeError:
#             return JsonResponse({'error': 'Invalid JSON data'}, status=400)

#     return JsonResponse({'error': 'Invalid request'}, status=400)

@login_required
@require_POST
def update_available_status(request):
    user = request.user
    user.available = request.POST.get('available') == 'true'
    user.save()
    return JsonResponse({'status': 'success'})

from django.views.decorators.http import require_GET
from django.views.decorators.csrf import ensure_csrf_cookie
from django.http import StreamingHttpResponse

from .sse_utils import connected_clients
from .signals import send_notification_signal
from django.dispatch import Signal, receiver

new_item=False
sse_connections = {}
consumer_last_name=''
consumer_first_name=''
consumer_number=''
consumer_photo=''
consumer_maps_link=''

@ensure_csrf_cookie
@require_GET
def sse(request, phone_number):
    response = StreamingHttpResponse(sse_generator(phone_number), content_type='text/event-stream')
    response['Cache-Control'] = 'no-cache'
    sse_connections[phone_number] = response
    return response

def sse_generator(phone_number):
    global new_item, new_item_phone_number,idd,consumer_last_name,consumer_first_name,consumer_number,consumer_photo,consumer_maps_link,consumer_x,consumer_y,desc,problem_photo
    # Simulate waiting for notifications
    yield f'data: {json.dumps({"message": "Waiting for notifications"})}\n\n'
    if new_item and new_item_phone_number == phone_number:
        notification_data = {"message": "New request !","idd":idd,"last_name":consumer_last_name,"first_name":consumer_first_name,"number":consumer_number,"maps_link":consumer_maps_link,"photo":consumer_photo,"x":consumer_x,"y":consumer_y,"desc":desc,"problem_photo":problem_photo}
        event_data = f'data: {json.dumps(notification_data)}\n\n'
        yield event_data
        new_item=False

@receiver(send_notification_signal)
def handle_send_notification(sender, **kwargs):
    global new_item, new_item_phone_number,idd,consumer_last_name,consumer_first_name,consumer_number,consumer_photo,consumer_maps_link,consumer_x,consumer_y,desc,problem_photo
    # Get the phone number from the signal arguments
    idd = kwargs.get('idd')
    phone_number = kwargs.get('phone_number')
    consumer_last_name = kwargs.get('consumer_last')
    consumer_first_name = kwargs.get('consumer_first')
    consumer_number = kwargs.get('consumer_number')
    consumer_maps_link = kwargs.get('consumer_maps_link')
    consumer_photo = kwargs.get('consumer_photo')
    consumer_x = kwargs.get('consumer_x')
    consumer_y = kwargs.get('consumer_y')
    desc = kwargs.get('desc')
    problem_photo = kwargs.get('problem_photo')
    #user_dispo= CustomUser.objects.filter(phone_number=phone_number).first()
    #print(f'the lasssssssssssssssssssssssssssstnameis {user_dispo.available}')

    # Simulate sending a notification
    notification_data = {"message": "New request !","idd":idd,"last_name":consumer_last_name,"first_name":consumer_first_name,"number":consumer_number,"maps_link":consumer_maps_link,"photo":consumer_photo,"x":consumer_x,"y":consumer_y,"desc":desc,"problem_photo":problem_photo}

    new_item=True
    new_item_phone_number = phone_number

    # Send the notification to the specific SSE connection associated with the phone number
    if phone_number in sse_connections:
        sse_connection = sse_connections[phone_number]
        event_data = f'data: {json.dumps(notification_data)}\n\n'

        print(event_data)
        #sse_connection.write(event_data)
        #sse_connection.flush()
    return new_item, new_item_phone_number



# def trackrating(request):
#     if request.method=='POST':
#         data=json.loads(request.body)
#         TrackRating.objects.update_or_create(
#             provider_number=data.get('provider_number'),
#             provider_service= data.get('provider_service'),
#             provider_name= data.get('provider_name'),
#             consumer_number=data.get('consumer_number'),
#             decription = data.get('decription'),
#             price=data.get('price'),
#             rating=data.get('rating')
                
#         )
#         return JsonResponse({'status': 'success'})



def update_provider_location(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        provider_number = data.get('provider_number')
        provider_x = data.get('provider_x')
        provider_y = data.get('provider_y')
        consumer_number = data.get('consumer_number')
        consumer_x = data.get('consumer_x')
        consumer_y = data.get('consumer_y')

        if provider_number and provider_x and provider_y:
            TrackLocation.objects.update_or_create(
                provider_number=provider_number,
                provider_x= provider_x,
                provider_y= provider_y,
                consumer_number=consumer_number,
                consumer_x = consumer_x,
                consumer_y=consumer_y
                
            )
            return JsonResponse({'status': 'success'})
        else:
            return HttpResponseBadRequest('Invalid data')
    else:
        return HttpResponseBadRequest('Invalid request method')

def get_consumer_location(request, consumer_number):
    try:
        #tracked_location = TrackLocation.objects.get(consumer_number=consumer_number)
        tracked_location = TrackLocation.objects.filter(consumer_number=consumer_number).order_by('-id').first()

        return JsonResponse({
            'consumer_number': tracked_location.consumer_number,
            'consumer_x': tracked_location.consumer_x,
            'consumer_y': tracked_location.consumer_y,
            'provider_x': tracked_location.provider_x,
            'provider_y': tracked_location.provider_y,
            'provider_number': tracked_location.provider_number,

        })
    except TrackLocation.DoesNotExist:
        return JsonResponse({'status': 'Consumer not found'})

